(function($) {
    $(document).ready(function() {
        var form = $('#adp-filter-form');
        var resultsWrapper = $('#adp-result-wrapper');
        var searchBtn = form.find('.adp-btn-primary');
        var originalBtnText = searchBtn.text();

        // Debounce for search input
        var debounceTimer;
        form.find('input, select').on('input change', function() {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(function() {
                form.trigger('submit');
            }, 500);
        });

        form.on('submit', function(e) {
            e.preventDefault();
            var formData = form.serializeArray();
            var data = {
                action: 'adp_filter',
                nonce: adp_ajax.nonce,
                paged: 1 // Reset to page 1
            };
            $.each(formData, function(i, field) {
                data[field.name] = field.value;
            });

            searchBtn.attr('disabled', true).html('<i class="fa-solid fa-spinner fa-spin-pulse"></i> جستجو...');
            resultsWrapper.css('opacity', 0.5);

            $.post(adp_ajax.ajax_url, data, function(response) {
                if (response.success) {
                    resultsWrapper.html(response.data.html);
                } else {
                    resultsWrapper.html('<p class="adp-empty">خطا یا هیچ نتیجه‌ای یافت نشد.</p>');
                }
            }).always(function() {
                searchBtn.attr('disabled', false).text(originalBtnText);
                resultsWrapper.css('opacity', 1);
            });
        });

        $('#adp-reset').on('click', function() {
            form.find('input[type=text]').val('');
            form.find('select').val('0');
            form.trigger('submit');
        });

        // جدید: انیمیشن لود نتایج
        resultsWrapper.on('load', function() {
            $(this).fadeIn(500);
        });
    });
})(jQuery);
