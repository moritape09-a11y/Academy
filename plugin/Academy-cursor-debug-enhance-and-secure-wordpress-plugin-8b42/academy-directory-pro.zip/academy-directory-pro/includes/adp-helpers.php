<?php
/**
 * کلاس توابع کمکی
 */
class ADP_Helpers {
    /**
     * نمایش ستاره‌های امتیاز
     * 
     * @param int $rating امتیاز (1 تا 5)
     * @return string HTML ستاره‌ها
     */
    public static function render_stars( $rating ) {
        $rating = intval( $rating );
        $rating = max( 1, min( 5, $rating ) );
        $out = '<div class="adp-stars" aria-hidden="true">';
        for ( $i = 1; $i <= 5; $i++ ) {
            $out .= ( $i <= $rating ) ? '<i class="fa-solid fa-star fa-fw star-on"></i>' : '<i class="fa-regular fa-star fa-fw star-off"></i>';
        }
        $out .= '</div>';
        return $out;
    }

    /**
     * نمایش فرم فیلتر
     * 
     * @param string $search جستجو
     * @param string $subject رشته
     * @param int $min_rating حداقل امتیاز
     * @param int $cols تعداد ستون‌ها
     * @return string HTML فرم
     */
    public static function render_filter_form( $search, $subject, $min_rating, $cols ) {
        $out = '<form id="adp-filter-form" class="adp-filter" method="get">';
        $out .= '<div class="adp-filter-row">';
        $out .= '<input type="text" name="adp_q" placeholder="' . esc_attr__( 'جستجو (نام آموزشگاه)...', 'academy-directory-pro' ) . '" value="' . esc_attr( $search ) . '" class="adp-input adp-input-search"/>';
        $out .= '<input type="text" name="adp_subject" placeholder="' . esc_attr__( 'جستجوی رشته (مثل طراحی سایت)...', 'academy-directory-pro' ) . '" value="' . esc_attr( $subject ) . '" class="adp-input"/>';
        $out .= '<select name="adp_min_rating" class="adp-input">';
        $out .= '<option value="0">' . __( 'همه امتیازها', 'academy-directory-pro' ) . '</option>';
        for ( $i = 1; $i <= 5; $i++ ) {
            $sel = ( $min_rating == $i ) ? ' selected' : '';
            $out .= '<option value="' . $i . '"' . $sel . '>' . $i . ' ' . __( 'ستاره و بالاتر', 'academy-directory-pro' ) . '</option>';
        }
        $out .= '</select>';
        $out .= '<button type="submit" class="adp-btn adp-btn-primary">' . __( 'جستجو', 'academy-directory-pro' ) . '</button>';
        $out .= '<button type="button" id="adp-reset" class="adp-btn">' . __( 'بازنشانی', 'academy-directory-pro' ) . '</button>';
        $out .= '<input type="hidden" name="cols" value="' . esc_attr( $cols ) . '">';
        $out .= '</div></form>';
        return $out;
    }

    /**
     * نمایش کارت آموزشگاه
     * 
     * @param int $post_id شناسه پست
     * @return string HTML کارت
     */
    public static function render_card( $post_id ) {
        $phone = get_post_meta( $post_id, '_adp_phone', true );
        $instagram = get_post_meta( $post_id, '_adp_instagram', true );
        $subjects = get_post_meta( $post_id, '_adp_subjects', true );
        $rating = get_post_meta( $post_id, '_adp_rating', true ) ?: 5;
        $featured = get_post_meta( $post_id, '_adp_featured', true ) === 'yes' ? ' adp-featured' : '';
        $out = '<article class="adp-card' . esc_attr( $featured ) . '" itemscope itemtype="https://schema.org/Organization">';
        $out .= '<div class="adp-card-inner">';
        if ( has_post_thumbnail() ) {
            $out .= '<div class="adp-thumb"><a href="' . get_permalink() . '">' . get_the_post_thumbnail( null, 'medium', array( 'itemprop' => 'image' ) ) . '</a></div>';
        }
        $out .= '<div class="adp-content">';
        $out .= '<h3 class="adp-title" itemprop="name"><a href="' . get_permalink() . '">' . get_the_title() . '</a></h3>';
        $out .= self::render_stars( $rating );
        if ( $subjects ) {
            $tags = array_map( 'trim', explode( ',', $subjects ) );
            $out .= '<div class="adp-tags" itemprop="keywords">';
            foreach ( $tags as $t ) {
                if ( $t ) $out .= '<span class="adp-tag adp-tag-yellow">' . esc_html( $t ) . '</span>';
            }
            $out .= '</div>';
        }
        $out .= '<div class="adp-excerpt">' . get_the_excerpt() . '</div>';
        $out .= '<ul class="adp-meta">';
        if ( $phone ) $out .= '<li itemprop="telephone"><i class="fa-solid fa-phone fa-fw"></i> ' . esc_html( $phone ) . '</li>';
        if ( $instagram ) $out .= '<li><i class="fa-brands fa-instagram fa-fw"></i> <a href="' . esc_url( $instagram ) . '" target="_blank" rel="noopener">' . __( 'اینستاگرام', 'academy-directory-pro' ) . '</a></li>';
        $out .= '</ul>';
        $out .= '</div></div></article>';
        return $out;
    }

    /**
     * نمایش صفحه تک آموزشگاه
     * 
     * @param string $content محتوای پیش‌فرض
     * @return string HTML صفحه تک
     */
    public static function render_single_content( $content ) {
        global $post;
        $post_id = $post->ID;
        $phone = get_post_meta( $post_id, '_adp_phone', true );
        $website = get_post_meta( $post_id, '_adp_website', true );
        $instagram = get_post_meta( $post_id, '_adp_instagram', true );
        $subjects = get_post_meta( $post_id, '_adp_subjects', true );
        $rating = get_post_meta( $post_id, '_adp_rating', true ) ?: 5;
        $priority = get_post_meta( $post_id, '_adp_priority', true ) ?: 100;
        $embed = get_post_meta( $post_id, '_adp_embed', true );
        $lat = get_post_meta( $post_id, '_adp_lat', true );
        $lng = get_post_meta( $post_id, '_adp_lng', true );

        $out = '<div class="adp-single" itemscope itemtype="https://schema.org/Organization">';
        $out .= '<div class="adp-single-header">';
        if ( has_post_thumbnail() ) {
            $out .= '<div class="adp-single-thumb">' . get_the_post_thumbnail( null, 'large', array( 'itemprop' => 'image' ) ) . '</div>';
        }
        $out .= '<div class="adp-single-info">';
        $out .= '<h1 class="adp-single-title" itemprop="name">' . get_the_title() . '</h1>';
        $out .= self::render_stars( $rating );
        $out .= '</div>';
        if ( $subjects ) {
            $tags = array_map( 'trim', explode( ',', $subjects ) );
            $out .= '<div class="adp-tags adp-tags-single" itemprop="keywords">';
            foreach ( $tags as $t ) {
                if ( $t ) $out .= '<span class="adp-tag adp-tag-yellow">' . esc_html( $t ) . '</span>';
            }
            $out .= '</div>';
        }
        $out .= '<div class="adp-single-content" itemprop="description">' . $content . '</div>';
        $out .= '<div class="adp-single-contact-box">';
        $out .= '<h3 class="adp-box-title"><i class="fa-solid fa-address-card"></i> ' . __( 'اطلاعات تماس و جزئیات', 'academy-directory-pro' ) . '</h3>';
        $out .= '<ul class="adp-single-meta">';
        if ( $phone ) $out .= '<li itemprop="telephone"><i class="fa-solid fa-phone"></i> <span>' . __( 'شماره تماس:', 'academy-directory-pro' ) . '</span> <a href="tel:' . esc_attr( $phone ) . '">' . esc_html( $phone ) . '</a></li>';
        if ( $website ) $out .= '<li itemprop="url"><i class="fa-solid fa-globe"></i> <span>' . __( 'وب‌سایت:', 'academy-directory-pro' ) . '</span> <a href="' . esc_url( $website ) . '" target="_blank" rel="noopener">' . esc_html( $website ) . '</a></li>';
        if ( $instagram ) $out .= '<li><i class="fa-brands fa-instagram"></i> <span>' . __( 'اینستاگرام:', 'academy-directory-pro' ) . '</span> <a href="' . esc_url( $instagram ) . '" target="_blank" rel="noopener">' . __( 'صفحه اینستاگرام', 'academy-directory-pro' ) . '</a></li>';
        if ( $priority !== '' ) $out .= '<li><i class="fa-solid fa-arrow-up-wide-short"></i> <span>' . __( 'اولویت نمایش:', 'academy-directory-pro' ) . '</span> ' . esc_html( $priority ) . '</li>';
        $out .= '</ul>';
        $out .= '</div>';
        if ( $embed ) {
            $out .= '<div class="adp-single-map-box">';
            $out .= '<h3 class="adp-box-title"><i class="fa-solid fa-map-location-dot"></i> ' . __( 'موقعیت آموزشگاه روی نقشه', 'academy-directory-pro' ) . '</h3>';
            // مجاز بر iframe برای نقشه - قبلاً sanitize شده در metabox save
            $out .= '<div class="adp-embed adp-embed-single">' . wp_kses_post( $embed ) . '</div>';
            $out .= '</div>';
        } elseif ( $lat && $lng ) {
            $out .= '<div class="adp-single-map-box">';
            $out .= '<h3 class="adp-box-title"><i class="fa-solid fa-map-location-dot"></i> ' . __( 'موقعیت روی نقشه', 'academy-directory-pro' ) . '</h3>';
            $out .= '<div id="adp-map" style="height:350px;"></div>';
            $out .= '<script>function initMap() { var map = new google.maps.Map(document.getElementById("adp-map"), {zoom: 15, center: {lat: ' . floatval( $lat ) . ', lng: ' . floatval( $lng ) . '}}); var marker = new google.maps.Marker({position: {lat: ' . floatval( $lat ) . ', lng: ' . floatval( $lng ) . '}, map: map}); } window.initMap = initMap;</script>';
            $out .= '</div>';
        }
        $out .= '</div>';
        return $out;
    }
}