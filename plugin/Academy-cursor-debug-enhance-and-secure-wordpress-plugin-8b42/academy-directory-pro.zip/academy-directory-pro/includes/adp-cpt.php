<?php
class ADP_CPT {
    public function __construct() {
        add_action( 'init', array( $this, 'register' ) );
    }

    public static function register() {
        $labels = array(
            'name'          => __( 'آموزشگاه‌ها', 'academy-directory-pro' ),
            'singular_name' => __( 'آموزشگاه', 'academy-directory-pro' ),
            'menu_name'     => __( 'آموزشگاه‌ها', 'academy-directory-pro' ),
        );
        $args = array(
            'labels'        => $labels,
            'public'        => true,
            'has_archive'   => true,
            'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'comments' ),
            'rewrite'       => array( 'slug' => 'academy' ),
            'show_in_rest'  => true,
        );
        register_post_type( 'academy', $args );
    }
}