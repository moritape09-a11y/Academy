<?php
/**
 * کلاس مدیریت AJAX
 */
class ADP_Ajax {
    public function __construct() {
        add_action( 'wp_ajax_adp_filter', array( $this, 'filter' ) );
        add_action( 'wp_ajax_nopriv_adp_filter', array( $this, 'filter' ) );
    }

    public function filter() {
        check_ajax_referer( 'adp_filter_nonce', 'nonce' );

        $search = isset( $_POST['adp_q'] ) ? sanitize_text_field( $_POST['adp_q'] ) : '';
        $subject = isset( $_POST['adp_subject'] ) ? sanitize_text_field( $_POST['adp_subject'] ) : '';
        $min_rating = isset( $_POST['adp_min_rating'] ) ? intval( $_POST['adp_min_rating'] ) : 0;
        $cols = isset( $_POST['cols'] ) ? max( 1, intval( $_POST['cols'] ) ) : 3;
        $per_page = get_option( 'adp_per_page_ajax', 9 );
        $paged = isset( $_POST['paged'] ) ? intval( $_POST['paged'] ) : 1;

        // Rate limiting - محدودسازی تعداد درخواست
        $user_ip = $this->get_user_ip();
        $rate_key = 'adp_rate_' . md5( $user_ip );
        $request_count = get_transient( $rate_key );
        
        if ( $request_count && $request_count >= 10 ) {
            ADP_Logger::log( "Rate limit exceeded for IP: {$user_ip}", 'warning' );
            wp_send_json_error( array( 'message' => __( 'درخواست زیاد. بعدا امتحان کنید.', 'academy-directory-pro' ) ) );
        }
        set_transient( $rate_key, ( $request_count ? $request_count + 1 : 1 ), 60 );

        $transient_key = 'adp_ajax_' . md5( serialize( $_POST ) );
        $response = get_transient( $transient_key );
        if ( false === $response ) {
            $args = array(
                'post_type'      => 'academy',
                'posts_per_page' => $per_page,
                'paged'          => $paged,
                'orderby'        => array( 'meta_value_num' => 'ASC', 'title' => 'ASC' ),
                'meta_key'       => '_adp_priority',
                'order'          => 'ASC',
            );

            $meta_query = array( 'relation' => 'AND' );
            if ( $min_rating > 0 ) {
                $meta_query[] = array( 'key' => '_adp_rating', 'value' => $min_rating, 'type' => 'NUMERIC', 'compare' => '>=' );
            }
            if ( !empty( $subject ) ) {
                $meta_query[] = array( 'key' => '_adp_subjects', 'value' => $subject, 'compare' => 'LIKE' );
            }
            if ( count( $meta_query ) > 1 ) {
                $args['meta_query'] = $meta_query;
            }
            if ( ! empty( $search ) ) {
                $args['s'] = $search;
            }

            $q = new WP_Query( $args );

            $html = '';
            if ( ! $q->have_posts() ) {
                $html .= '<p class="adp-empty">' . __( 'هیچ آموزشی یافت نشد.', 'academy-directory-pro' ) . '</p>';
            } else {
                $html .= '<div class="adp-grid adp-cols-' . esc_attr( $cols ) . '">';
                while ( $q->have_posts() ) {
                    $q->the_post();
                    $html .= ADP_Helpers::render_card( get_the_ID() );
                }
                $html .= '</div>';
                $html .= '<div class="adp-pagination">' . paginate_links( array( 'total' => $q->max_num_pages, 'current' => $paged ) ) . '</div>';
            }

            wp_reset_postdata();
            $response = array( 'html' => $html, 'max_pages' => $q->max_num_pages );
            set_transient( $transient_key, $response, 300 );
        }

        wp_send_json_success( $response );
    }

    /**
     * دریافت IP کاربر
     * 
     * @return string
     */
    private function get_user_ip() {
        $ip_keys = array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR' );
        
        foreach ( $ip_keys as $key ) {
            if ( ! empty( $_SERVER[ $key ] ) ) {
                $ip = sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) );
                if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
                    return $ip;
                }
            }
        }
        
        return '0.0.0.0';
    }
}